import dataiku
from dataiku import pandasutils as pdu
import pandas as pd

import dash
import dash_html_components as html
import dash_pivottable
from dash.dependencies import Input, Output


#app = dash.Dash(__name__)
app.layout = html.Div([html.H1('Cost Analysis', id="titleDash"),html.Div(id="pivottable_div")])

##server = app.server

@app.callback(Output("pivottable_div", "children"), [Input("titleDash", "value")])
def refresh_pivottable(n_clicks):
        
    dku_input = dataiku.Dataset("Staff_modeling_Simu")
    df_input = dku_input.get_dataframe()
    data_list = df_input.values.tolist()
    data_list.insert(0,df_input.columns.values.tolist())
        
    return [
        dash_pivottable.PivotTable(id="pivot_table", data=data_list,cols=["Gender"],rows=["Department"],vals=["Salary"])
    ]

